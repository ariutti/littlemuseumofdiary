# README

Read the documentation here: https://sourceforge.net/p/raspberry-gpio-python/wiki/Inputs/